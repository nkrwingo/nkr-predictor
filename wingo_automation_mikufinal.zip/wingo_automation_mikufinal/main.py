from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
import time
import gspread
from oauth2client.service_account import ServiceAccountCredentials
import pickle
import os

# Google Sheet setup
scope = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/drive"]
creds = ServiceAccountCredentials.from_json_keyfile_name("service_account.json", scope)
client = gspread.authorize(creds)
sheet = client.open("NKR Wingo Data").worksheet("nkr_sheet")

# Chrome setup
chrome_options = Options()
chrome_options.add_argument('--headless')
chrome_options.add_argument('--no-sandbox')
chrome_options.add_argument('--disable-dev-shm-usage')

driver = webdriver.Chrome(options=chrome_options)

# Load model if exists
model = None
if os.path.exists("wingo_model.pkl"):
    with open("wingo_model.pkl", "rb") as f:
        model = pickle.load(f)

def predict_local(number):
    size = "Big" if number >= 5 else "Small"
    if number in [1, 3, 7, 9]:
        color = "Green"
    elif number in [2, 4, 6, 8]:
        color = "Red"
    elif number == 0:
        color = "Red + Violet"
    elif number == 5:
        color = "Green + Violet"
    else:
        color = "Unknown"
    return size, color

def scrape_and_update():
    driver.get("https://damangames.bet/#/home/AllLotteryGames/WinGo?id=1")
    time.sleep(8)

    try:
        period = driver.find_element(By.CLASS_NAME, "gameRecord_period").text.strip()
        result = driver.find_element(By.CLASS_NAME, "gameRecord_openNum").text.strip()

        # Check duplicates
        existing_periods = sheet.col_values(1)
        if period in existing_periods:
            print(f"⏭️ Period {period} already exists. Skipping.")
            return

        number = int(result)

        if model:
            size_model = model["size_model"]
            color_model = model["color_model"]

            size_pred = size_model.predict([[number]])[0]
            color_pred = color_model.predict([[number]])[0]

            size = "Big" if size_pred == 1 else "Small"

            if color_pred == 1:
                color = "Green"
            elif color_pred == 2:
                color = "Red"
            elif color_pred == 3:
                color = "Red + Violet"
            elif color_pred == 4:
                color = "Green + Violet"
            else:
                color = "Unknown"
        else:
            size, color = predict_local(number)

        # Append to Google Sheet
        sheet.append_row([period, result, size, color])
        print(f"✅ Updated: {period} | {result} | {size} | {color}")

    except Exception as e:
        print("❌ Scraping error:", e)

# Run every 60 seconds
while True:
    scrape_and_update()
    time.sleep(60)
