# Wingo Pro Automation (NKR)

This project scrapes live Wingo results from DamanGames, predicts the next outcome using trained ML models, and stores data in Google Sheets in real-time.

---

## Features

- ✅ Live scraping from DamanGames (1-minute WinGo)
- ✅ Google Sheets integration (auto-update)
- ✅ Predicts:
  - Big / Small
  - Color
  - Next number
- ✅ Auto-trains model using 5000+ records
- ✅ Railway/Koyeb cloud-ready (with Docker)
- ✅ Secure `service_account.json` via `.gitignore`

---

## Setup Instructions

1. Clone this repo  
2. Add your `service_account.json` file (not included)
3. Run:
   ```bash
   python train_model.py
   python main.py
