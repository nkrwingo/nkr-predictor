import pickle

# Load trained model
try:
    with open("wingo_model.pkl", "rb") as f:
        models = pickle.load(f)
except FileNotFoundError:
    print("❌ Model file 'wingo_model.pkl' not found.")
    exit()

model_size = models["size_model"]
model_color = models["color_model"]
model_number = models["number_model"]

# Take user input
try:
    number = int(input("Enter current Wingo number (0–9): "))
    if not (0 <= number <= 9):
        raise ValueError("Number must be between 0 and 9.")
except ValueError as e:
    print("❌", e)
    exit()

# Predict next number
next_number = model_number.predict([[number]])[0]

# Predict size
size_pred = model_size.predict([[number]])[0]
size = "Big" if size_pred == 1 else "Small"

# Predict color
color_pred = model_color.predict([[number]])[0]
color_map = {
    1: "Green",
    2: "Red",
    3: "Red + Violet",
    4: "Green + Violet"
}
color = color_map.get(color_pred, "Unknown")

# Final output
print(f"\n✅ Prediction for {number}:")
print(f"- Next Number = {next_number}")
print(f"- Size        = {size}")
print(f"- Color       = {color}")
