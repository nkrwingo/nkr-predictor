import gspread
from oauth2client.service_account import ServiceAccountCredentials
from sklearn.ensemble import RandomForestClassifier
import pickle

# Setup Google Sheets connection
scope = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/drive"]
creds = ServiceAccountCredentials.from_json_keyfile_name("service_account.json", scope)
client = gspread.authorize(creds)
sheet = client.open("NKR Wingo Data").worksheet("nkr_sheet")

# Fetch data
data = sheet.get_all_records()

if len(data) < 5000:
    print(f"❌ Only {len(data)} rows found. Minimum 5000 needed to train.")
    exit()

# Prepare training data
X = []
y_size = []
y_color = []
y_number = []

for i in range(len(data) - 1):
    try:
        current = data[i]
        next_ = data[i + 1]

        num = int(current["Result"])
        next_num = int(next_["Result"])

        # Size label
        size = 1 if current["Big/Small"] == "Big" else 0

        # Color label
        color_map = {
            "Green": 1,
            "Red": 2,
            "Red + Violet": 3,
            "Green + Violet": 4
        }
        color = color_map.get(current["Color"], 0)

        # Features and labels
        X.append([num])
        y_size.append(size)
        y_color.append(color)
        y_number.append(next_num)

    except Exception as e:
        print("Skipping row:", e)

# Train models
model_size = RandomForestClassifier()
model_color = RandomForestClassifier()
model_number = RandomForestClassifier()

model_size.fit(X, y_size)
model_color.fit(X, y_color)
model_number.fit(X, y_number)

# Save to one file
with open("wingo_model.pkl", "wb") as f:
    pickle.dump({
        "size_model": model_size,
        "color_model": model_color,
        "number_model": model_number
    }, f)

print("✅ Model trained and saved as wingo_model.pkl")
